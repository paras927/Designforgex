import React from 'react';
import ChatPanel from './chat/ChatPanel.jsx';
import CanvasEngine from './rendering/CanvasEngine.jsx';
import VaultDashboard from './vault/VaultDashboard.jsx';

export default function App() {
  return (
    <div className="flex h-screen w-screen bg-gradient-to-br from-gray-100 to-slate-200">
      <CanvasEngine />
      <div className="flex flex-col w-96 bg-white bg-opacity-70 p-4 shadow-lg">
        <ChatPanel />
        <VaultDashboard />
      </div>
    </div>
  );
}