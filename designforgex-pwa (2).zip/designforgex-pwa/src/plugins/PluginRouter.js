export function routeToPlugin(intent) {
  if (intent.includes("simulate wind")) return "AtmosFlightSimX";
  if (intent.includes("organic") || intent.includes("biomorph")) return "BioMorphBuilder";
  return "GeometryCore";
}