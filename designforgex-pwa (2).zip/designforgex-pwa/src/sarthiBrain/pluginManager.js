export function executePlugin(plugin, params) {
  if (plugin === "AtmosFlightSimX") {
    return { status: "success", output: "Simulated airflow successfully" };
  }
  return { status: "ok", output: "Generic geometry modified." };
}