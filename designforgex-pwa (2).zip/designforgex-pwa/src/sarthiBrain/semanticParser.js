export function interpret(message) {
  const lower = message.toLowerCase();

  if (lower.includes("lighter")) return { plugin: "optimizer-core", reply: "Reducing mass…" };
  if (lower.includes("simulate wind")) return { plugin: "AtmosFlightSimX", reply: "Running wind test…" };
  return { reply: "Intent recognized. Building shape..." };
}