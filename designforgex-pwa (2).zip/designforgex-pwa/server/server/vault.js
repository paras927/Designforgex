const express = require('express');
const router = express.Router();

let vaultStore = [];

router.post('/save', (req, res) => {
  const { name, tags, designData } = req.body;
  vaultStore.push({ name, tags, designData, timestamp: Date.now() });
  res.json({ success: true });
});

router.get('/list', (req, res) => {
  res.json({ entries: vaultStore });
});

module.exports = router;