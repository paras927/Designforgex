self.addEventListener("install", event => {
  event.waitUntil(
    caches.open("dfx-cache").then(cache => cache.addAll(["/", "/index.html"]))
  );
});